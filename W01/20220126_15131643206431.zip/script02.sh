#!/bin/bash
# Name:         script02
# Aufruf:       ./script02.sh
# Beschreibung: Gibt den Hostnamen und die Sprache aus
# Autor:        David Minder
# Version:      1.0
# Datum:        26.01.2022

echo $HOSTNAME #Hostname ausgeben
echo $LANGUAGE #Sprache ausgeben
