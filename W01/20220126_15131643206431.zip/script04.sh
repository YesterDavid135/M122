#!/bin/bash
# Name:         script04
# Aufruf:       ./script04.sh
# Beschreibung: Kopiert die Testdaten in ein Unterverzeichnis
# Autor:        David Minder
# Version:      1.0
# Datum:        26.01.2022

cd Testdaten
mkdir test
cp *.* test
