#!/bin/bash
# Name:         script03
# Aufruf:       ./script03.sh text
# Beschreibung: Gibt den Wert des Parameters aus
#               text: Wird ausgegeben
# Autor:        David Minder
# Version:      1.0
# Datum:        26.01.2022

echo $1